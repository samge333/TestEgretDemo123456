class NetworkProtocol {
	public constructor() {
	}

	// public static parser_func(param: string) {

	// }
}