class EvtName {
	// //FightQTEController
	// static QteCtrlNextAttackRole = "fight_qte_controller_qte_to_auto_next_attack_role";	//去找下一个角色

	//FightRoleController
	static RoleCtrlNextAttackRole = "fight_role_controller_qte_to_next_attack_role";	//下一个进攻角色
}