class TalentMould {
	public constructor() {
	}
}